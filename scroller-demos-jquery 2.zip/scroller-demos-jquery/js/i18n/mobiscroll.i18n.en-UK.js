// English (UK)
(function () {
    mobiscroll.i18n['en-GB'] = mobiscroll.i18n['en-UK'] = {
        dateFormat: 'dd/mm/yy',
        timeFormat: 'HH:ii'
    };
})();
